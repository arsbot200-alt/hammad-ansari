import React from 'react';
import {
  ArrowLeft,
  ChevronRight,
  HardDrive,
  Moon,
  SlidersHorizontal,
  Cloud,
  ShieldCheck,
  Code2,
  Download,
  ExternalLink,
  Server,
  Zap,
} from 'lucide-react';
import { StorageStats } from '../types';
import { formatBytes, triggerDownload } from '../utils/format';

interface SettingsViewProps {
  onBack: () => void;
  stats: StorageStats | null;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  onOpenVercelModal: () => void;
  sortOption: string;
  onChangeSortOption: (val: any) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  onBack,
  stats,
  isDarkMode,
  onToggleTheme,
  onOpenVercelModal,
  sortOption,
  onChangeSortOption,
}) => {
  const [showHidden, setShowHidden] = React.useState(false);

  const handleDownloadRenderZip = () => {
    triggerDownload('/api/download-render-zip', 'gallery-render-deploy.zip');
  };

  const handleDownloadVercelZip = () => {
    triggerDownload('/api/download-project-zip', 'gallery-vercel-deploy.zip');
  };

  return (
    <div className="space-y-6 pb-24 max-w-lg md:max-w-2xl lg:max-w-4xl mx-auto px-4">
      {/* Header matching Mockup Screen 8: ArrowLeft, "Settings" */}
      <div className="flex items-center gap-3 pt-2 pb-1">
        <button
          onClick={onBack}
          className="p-2 rounded-full hover:bg-zinc-800 text-zinc-300 hover:text-white"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-xl font-bold tracking-tight text-white font-sans">
          Settings
        </h1>
      </div>

      {/* Prominent Render Export Card */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-teal-950/30 to-zinc-900/60 border border-emerald-500/30 space-y-3">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Server className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-bold text-white">Render.com Web Service Package</h3>
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono font-semibold">
                Free Tier
              </span>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Complete persistent Node.js service with <code className="text-amber-400 font-mono">render.yaml</code> pre-configured. No execution timeouts or upload size limits.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 pt-1">
          <button
            onClick={handleDownloadRenderZip}
            className="flex-1 min-w-[180px] flex items-center justify-center gap-2 py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-semibold text-xs transition-all shadow-md shadow-emerald-600/30"
          >
            <Download className="w-4 h-4" />
            <span>Download Render ZIP</span>
          </button>

          <button
            onClick={onOpenVercelModal}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium transition-colors"
          >
            <Code2 className="w-4 h-4 text-emerald-400" />
            <span>Deploy Guide</span>
          </button>
        </div>
      </div>

      {/* General Section matching Screen 8 */}
      <div className="space-y-3">
        <span className="text-xs font-semibold text-zinc-500 uppercase tracking-wider px-1">
          General
        </span>

        <div className="bg-[#131722] border border-zinc-800 rounded-2xl divide-y divide-zinc-800/60 overflow-hidden text-xs">
          {/* Theme */}
          <div
            onClick={onToggleTheme}
            className="flex items-center justify-between p-3.5 hover:bg-zinc-800/40 cursor-pointer transition-colors"
          >
            <span className="font-medium text-white">Theme</span>
            <div className="flex items-center gap-1.5 text-zinc-400">
              <span>{isDarkMode ? 'Dark' : 'Light'}</span>
              <ChevronRight className="w-4 h-4 text-zinc-600" />
            </div>
          </div>

          {/* Sort by */}
          <div
            onClick={() =>
              onChangeSortOption(sortOption === 'newest' ? 'oldest' : 'newest')
            }
            className="flex items-center justify-between p-3.5 hover:bg-zinc-800/40 cursor-pointer transition-colors"
          >
            <span className="font-medium text-white">Sort by</span>
            <div className="flex items-center gap-1.5 text-zinc-400">
              <span>{sortOption === 'newest' ? 'Date taken (Newest)' : 'Date taken (Oldest)'}</span>
              <ChevronRight className="w-4 h-4 text-zinc-600" />
            </div>
          </div>

          {/* Show hidden albums (Toggle switch matching Screen 8) */}
          <div className="flex items-center justify-between p-3.5">
            <span className="font-medium text-white">Show hidden albums</span>
            <button
              onClick={() => setShowHidden(!showHidden)}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                showHidden ? 'bg-blue-600 justify-end' : 'bg-zinc-700 justify-start'
              }`}
            >
              <div className="w-4 h-4 rounded-full bg-white shadow-sm" />
            </button>
          </div>

          {/* Backup & sync / Render & Vercel API */}
          <div
            onClick={onOpenVercelModal}
            className="flex items-center justify-between p-3.5 hover:bg-zinc-800/40 cursor-pointer transition-colors"
          >
            <span className="font-medium text-white">Cloud Hosting & Deploy Guides</span>
            <div className="flex items-center gap-1.5 text-emerald-400 font-semibold font-mono text-[11px]">
              <span>Render / Vercel</span>
              <ChevronRight className="w-4 h-4 text-zinc-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Storage Section matching Screen 8 */}
      <div className="space-y-3">
        <span className="text-xs font-semibold text-zinc-500 uppercase tracking-wider px-1">
          Storage
        </span>

        <div className="bg-[#131722] border border-zinc-800 rounded-2xl p-4 space-y-3 text-xs">
          <div className="flex items-center justify-between font-mono">
            <span className="text-zinc-400">Used space</span>
            <span className="text-white font-semibold">
              {stats?.formattedSize || '0 B'} / Unlimited Lossless
            </span>
          </div>

          {/* Blue progress bar matching Screen 8 */}
          <div className="w-full bg-zinc-800 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-blue-500 h-full rounded-full transition-all duration-300"
              style={{
                width: `${Math.min(
                  100,
                  Math.max(8, ((stats?.totalSizeBytes || 0) / (50 * 1024 * 1024)) * 100)
                )}%`,
              }}
            />
          </div>

          <p className="text-[11px] text-zinc-500 leading-normal">
            Zero-compression original storage. Files are kept byte-for-byte lossless.
          </p>
        </div>
      </div>

      {/* About Section matching Screen 8 */}
      <div className="space-y-3">
        <span className="text-xs font-semibold text-zinc-500 uppercase tracking-wider px-1">
          Export & About
        </span>

        <div className="bg-[#131722] border border-zinc-800 rounded-2xl divide-y divide-zinc-800/60 overflow-hidden text-xs">
          <div className="flex items-center justify-between p-3.5">
            <span className="font-medium text-white">App version</span>
            <span className="text-zinc-400 font-mono">1.0.0 (Production)</span>
          </div>

          <div
            onClick={handleDownloadRenderZip}
            className="flex items-center justify-between p-3.5 hover:bg-zinc-800/40 cursor-pointer transition-colors"
          >
            <div className="flex items-center gap-2">
              <Server className="w-4 h-4 text-emerald-400" />
              <span className="font-medium text-emerald-400">Download Render Deployment ZIP</span>
            </div>
            <Download className="w-4 h-4 text-emerald-400" />
          </div>

          <div
            onClick={handleDownloadVercelZip}
            className="flex items-center justify-between p-3.5 hover:bg-zinc-800/40 cursor-pointer transition-colors"
          >
            <div className="flex items-center gap-2">
              <Cloud className="w-4 h-4 text-blue-400" />
              <span className="font-medium text-zinc-400 hover:text-white">Download Vercel ZIP</span>
            </div>
            <Download className="w-4 h-4 text-zinc-400" />
          </div>

          <div
            onClick={onOpenVercelModal}
            className="flex items-center justify-between p-3.5 hover:bg-zinc-800/40 cursor-pointer transition-colors"
          >
            <span className="font-medium text-white">Render & API Endpoints Documentation</span>
            <ChevronRight className="w-4 h-4 text-zinc-600" />
          </div>

          <div className="flex items-center justify-between p-3.5 hover:bg-zinc-800/40 cursor-pointer transition-colors">
            <span className="font-medium text-white">Privacy policy</span>
            <ChevronRight className="w-4 h-4 text-zinc-600" />
          </div>

          <div className="flex items-center justify-between p-3.5 hover:bg-zinc-800/40 cursor-pointer transition-colors">
            <span className="font-medium text-white">Terms of service</span>
            <ChevronRight className="w-4 h-4 text-zinc-600" />
          </div>
        </div>
      </div>
    </div>
  );
};
